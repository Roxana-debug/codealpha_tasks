<template>
  <main>
    <h1>Welcome</h1>
  </main>
</template>
