# Project-Management-System
Designed using Technologies like HTML, CSS, JavaScript, Bootstrap, Jquery, PHP, and MySQL Database. Project Management System is a means of managing a project by planning, organizing, and managing its different required aspects. It  is a web-based platform designed to help individuals and teams effectively plan, track, and manage projects of all sizes.

Check the Working of the Project Here : https://bit.ly/44KpAO3

Deployed Link : https://projectmanagement-lakshay.000webhostapp.com/

Username: User

Password: Password
